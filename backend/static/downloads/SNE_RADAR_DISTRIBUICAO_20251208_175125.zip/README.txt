Este é um arquivo de teste para simular o download do SNE Radar.
